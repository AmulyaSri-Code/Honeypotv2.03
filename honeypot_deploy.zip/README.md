# Single-File Honeypot & Dashboard

A lightweight, single-file honeypot supporting HTTP, SSH, and Telnet, with a real-time web dashboard.

## 🚀 Quick Start

### Installation (Ubuntu/Fedora)
Run the automated installer:
```bash
sudo ./install.sh
```

### Managing Services
Start both the honeypot and dashboard at once:
```bash
sudo systemctl start honeypot honeypot-dashboard
```

Stop them:
```bash
sudo systemctl stop honeypot honeypot-dashboard
```

Check status:
```bash
sudo systemctl status honeypot honeypot-dashboard
```

### Accessing the Dashboard
Open your browser and visit:
`http://<SERVER_IP>:8000`

## 🛠️ Features
*   **Fake Shell**: SSH/Telnet attackers get a simulated Ubuntu terminal.
*   **Logging**: All activity (including command payloads) is logged to MySQL.
*   **Live Dashboard**: Real-time attack feed via WebSockets.
